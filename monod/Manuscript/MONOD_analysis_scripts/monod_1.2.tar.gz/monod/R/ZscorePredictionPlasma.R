#' prediction unknow samples/matrix plasma with normal plasma as the background
#' @param unknow sample mhl matrix, normal plasma mhl matrix and biomarker list (bio)
#' @return predicted result for each unknow samples, including Z-score, P-value and potential tissue-of-origin
#' @export
ZscorePredictionPlasma<-function(test,ncp,bio,tt=0.01){
  rlt<-list()
  test<-test[rownames(test) %in% rownames(bio),]
  ncp<-ncp[rownames(ncp) %in% rownames(bio),] 
  ccp<-test[rownames(test) %in% rownames(ncp),]
  npr<-apply(ncp,2,function(x) table(unlist(lapply(bio[match(rownames(ncp)[which(x>tt)],rownames(bio)),]$group,function(x) unlist(strsplit(x,","))))))
  ccpr<-apply(ccp,2,function(x) table(unlist(lapply(bio[match(rownames(ccp)[which(x>tt)],rownames(bio)),]$group,function(x) unlist(strsplit(x,","))))))
  rlt$nprscore<-Zscore(npr,npr)
  rlt$ccprscore<-Zscore(ccpr,npr)
  rlt1<-apply(Zscore(ccpr,npr),2,function(x) rownames(npr)[which.max(x)])
  rlt2<-apply(Zscore(npr,npr),2,function(x) rownames(npr)[which.max(x)])
  rlt$test<-rlt1
  rlt$background<-rlt2
  return(rlt)
}