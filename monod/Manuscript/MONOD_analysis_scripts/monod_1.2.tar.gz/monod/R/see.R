#' Check a Matrix
#' This function check the first few parts of the data.frame or matrix.
#' So that you can be understand the structure of the data quickly.Othe
#' rwise, you need apply str to check the structure. 
#' @param A matrix or data.frame
#' @return A matrix of the infile
#' @export
see<-function(x){
  x=x[1:3,1:3]
  x
}
