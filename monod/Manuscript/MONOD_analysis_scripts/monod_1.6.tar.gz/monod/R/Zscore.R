#' calculate Z-score for cancer plasma compared with normal plasma
#' @param tissue-specific biomarker counts in cancer plasma and normal plasma 
#' @return Z-score matrix
#' @export
Zscore<-function (ccpr, npr)
{
  ccpr<-scale(ccpr)
  npr<-scale(npr)
  Zmax <- matrix(0, nrow = nrow(ccpr), ncol = ncol(ccpr))
  for (i in 1:ncol(ccpr)) {
    for (k in 1:nrow(npr)) {
      idx <- 1:ncol(npr)
      zmp <- (ccpr[k, i] - mean(npr[k, idx]))/(sd(npr[k,
                                                      idx]) * sqrt((length(npr[k, idx]) - 1)/(length(npr[k,
                                                                                                         idx]))))
      Zmax[k, i] = zmp
    }
  }
  rownames(Zmax) = rownames(ccpr)
  colnames(Zmax) = colnames(ccpr)
  Zmax
}

