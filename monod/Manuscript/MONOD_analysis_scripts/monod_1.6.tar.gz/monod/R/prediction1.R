#' prediction
#' @param MHL matrix, biomarker and threshold
#' @return figure
#' @export
prediction1<-function(data,bio,tt=0.6){
  rlt<-list()
  input<-data[na.omit(match(rownames(bio),rownames(data))),]
  bio<-bio[na.omit(match(rownames(input),rownames(bio))),]
  factors<-c("Brain","Colon","Intestine","Kidney","Liver","Lung","Pancreas","Spleen","Stomach","WBC")
  testcounts<-apply(input,2,function(x) table(factor(unlist(lapply(bio[match(rownames(input)[which(x>tt)],rownames(bio)),]$group,function(x) unlist(strsplit(x,",")))),levels=factors)))
  backcounts<-table(unlist(lapply(bio[match(rownames(input),rownames(bio)),]$group,function(x) unlist(strsplit(x,",")))))
  prediction<-apply(apply(testcounts,2,function(x) x/backcounts),2,function(x) rownames(backcounts)[which.max(x)])
  score<-apply(testcounts,2,function(x) x/backcounts)
  rlt$testcounts=testcounts
  rlt$backcounts=backcounts
  rlt$prediction=prediction
  rlt$score=score
  return(rlt)
}
