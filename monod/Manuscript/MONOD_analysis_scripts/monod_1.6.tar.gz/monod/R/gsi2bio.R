#' transfer gsi2bio format
#' @param gsi result form gsi function
#' @return bio format which can be used to publish
#' @export
gsi2bio<-function(gsirlt){
  cor2bed<-function(cor){
    cor<-as.character(cor)
    a<-unlist(lapply(strsplit(cor,split=c(":")),function(x) strsplit(x,"-")))
    bed<-matrix(a,ncol=3,byrow=T)
    return(data.frame(bed))
  }
  bio<-data.frame(cor2bed(gsirlt[,1]),gsirlt[,2:5])
  rownames(bio)<-gsirlt[,1]
  return(bio)
}
