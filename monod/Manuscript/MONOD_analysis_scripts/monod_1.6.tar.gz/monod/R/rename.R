#' rename of raw data matrix of MHL
#' @param raw input of MHL or AMF matrix
#' @return new matrix with renamed variable name
#' @export
rename<-function (data){
  Data = data[, grep("STL|N37|ENC|SRX|age|new|centenarian|WB|CTT|HCT|X7.T|X6.T|X6.P|RRBS.6P|X7.P|RRBS.7P|NC.P", 
                     colnames(data))]
  colnames(Data)[grep(".", colnames(Data))] <- unlist(lapply(colnames(Data)[grep(".", 
                                                                                 colnames(Data))], function(x) unlist(strsplit(x, ".hapInfo|.sorted"))[1]))
  colnames(Data) <- gsub("[.]", "-", colnames(Data))
  colnames(Data)[grep("age|new|centenarian|middle", colnames(Data))] <- "WBC"
  colnames(Data)[grep("X6.T|CTT|CCT", colnames(Data))] <- "CCT"
  colnames(Data)[grep("X7.T|LCT", colnames(Data))] <- "LCT"
  colnames(Data)[grep("N37|STL|ENC", colnames(Data))] <- as.character(saminfo[match(colnames(Data)[grep("N37|STL|ENC", 
                                                                                                        colnames(Data))], saminfo[, 1]), 2])
  colnames(Data)[grep("X6.P|RRBS.6P", colnames(Data))] <- "CCP"
  colnames(Data)[grep("X7.P|RRBS.7P", colnames(Data))] <- "LCP"
  colnames(Data)[grep("NC.P", colnames(Data))] <- "NP"
  colnames(Data)[grep("X7.T|SRX381722|SRX381719|SRX381716", 
                      colnames(Data))] <- "LCT"
  colnames(Data)[grep("X6.T|CTT|SRX381569", colnames(Data))] <- "CCT"
  return(Data)
}
