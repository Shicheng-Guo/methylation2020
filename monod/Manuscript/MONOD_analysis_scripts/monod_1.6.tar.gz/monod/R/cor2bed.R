#' cor2bed
#' @param array of coordination
#' @return data.frame of bed regions
#' @export
cor2bed<-function(cor){
  cor<-as.character(cor)
  a<-unlist(lapply(strsplit(cor,split=c(":")),function(x) strsplit(x,"-")))
  bed<-matrix(a,ncol=3,byrow=T)
  bed<-data.frame(bed,cor)
  return(data.frame(bed))
}