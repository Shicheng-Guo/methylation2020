#' prediction unknow samples/matrix plasma with normal plasma as the background
#' @param unknow sample mhl matrix, normal plasma mhl matrix and biomarker list (bio)
#' @return predicted result for each unknow samples, including Z-score, P-value and potential tissue-of-origin
#' @export
ZscorePredictionPlasma2<-function (test, ncp, bio, tt = 0.001)
{
  rlt <- list()
  test <- test[rownames(test) %in% rownames(bio), ]
  ncp <- ncp[rownames(ncp) %in% rownames(bio), ]
  ccp <- test[rownames(test) %in% rownames(ncp), ]
  bio <- bio[na.omit(match(rownames(test), rownames(bio))),
             ]
  backcounts <- table(unlist(lapply(bio[match(rownames(test),
                                              rownames(bio)), ]$group, function(x) unlist(strsplit(x,
                                                                                                   ",")))))
  factors <- c("Brain", "Colon", "Intestine", "Kidney", "Liver",
               "Lung", "Pancreas", "Stomach")
  testcounts <- apply(test, 2, function(x) table(factor(unlist(lapply(bio[match(rownames(test)[which(x >
                                                                                                       tt)], rownames(bio)), ]$group, function(x) unlist(strsplit(x,
                                                                                                                                                                  ",")))), levels = factors)))
  score <- apply(testcounts, 2, function(x) x/backcounts)
  prediction <- apply(score, 2, function(x) rownames(backcounts)[which.max(x)])
  
  
  npr <- apply(ncp, 2, function(x) table(unlist(lapply(bio[match(rownames(ncp)[which(x >
                                                                                       tt)], rownames(bio)), ]$group, function(x) unlist(strsplit(x,
                                                                                                                                                  ","))))))
  ccpr <- apply(ccp, 2, function(x) table(unlist(lapply(bio[match(rownames(ccp)[which(x >
                                                                                        tt)], rownames(bio)), ]$group, function(x) unlist(strsplit(x,
                                                                                                                                                   ","))))))
  npr<-apply(npr, 2, function(x) x/backcounts)
  ccpr<-apply(ccpr, 2, function(x) x/backcounts)
  
  rlt$testcounts <- testcounts
  rlt$backcounts <- backcounts
  
  rlt$score <- score
  rlt$npn <- npr
  rlt$ccpn <- ccpr
  rlt$nprscore <- Zscore(npr, npr)
  rlt$ccprscore <- Zscore(ccpr, npr)
  rlt$test <- apply(Zscore(ccpr, npr), 2, function(x) rownames(npr)[which.max(x)])
  rlt$background <- apply(Zscore(npr, npr), 2, function(x) rownames(npr)[which.max(x)])
  return(rlt)
}
