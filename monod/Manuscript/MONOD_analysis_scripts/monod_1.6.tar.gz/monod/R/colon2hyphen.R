#' rename rowname of Dinh's MHL matrix since she give the rowname as chr1:2048:9489
#' @param rowname of dinh's MHL matrix
#' @return new array replace : with -
#' @export
colon2hyphen<-function(x){
  colon<-lapply(x,function(x) unlist(strsplit(x,":")))
  cor<-lapply(colon,function(x) paste(x[1],":",x[2],"-",as.numeric(x[3])-1,sep=""))
  return(unlist(cor))
}