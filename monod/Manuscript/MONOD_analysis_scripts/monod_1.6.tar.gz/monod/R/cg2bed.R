#' cg 2 bed
#' @param data matrix
#' @return data matrix
#' @export
bed2cor<-function(bed){
  cor<-apply(bed,1,function(x) paste(x[1],":",as.numeric(x[2])-extend,"-",as.numeric(x[3])+extend,sep=""))
  cor<-gsub(" ","",cor)
  return(cor)
}
cg2bed<-function(cg,extend=100){
  ref<-read.table("~/work/db/hg19/GPL13534.sort.bed",head=F,sep="\t")
  bed<-ref[match(cg,ref[,4]),1:3]
  bed[,2]=bed[,2]-extend
  bed[,3]=bed[,3]+extend
  cor<-bed2cor(bed)
  rlt<-data.frame(bed,cor,cg)
  return(rlt)
}
