#' Prepare heatamp plot with missing value as black points
#' @param data matrix with colnames of Group index
#' @return figure
#' @export
heatmap2<-function(mydata,output,cexRow=0.5,cexCol=0.5){
  hclustfunc <- function(x) hclust(x, method="complete")
  distfunc <- function(x) dist(x, method="euclidean")
  # perform clustering on rows and columns
  cl.row <- hclustfunc(distfunc(mydata))
  cl.col <- hclustfunc(distfunc(t(mydata)))
  # extract cluster assignments; i.e. k=8 (rows) k=5 (columns)
  gr.row <- cutree(cl.row, 6)
  # gr.col <- cutree(cl.col, 5)
  # require(RColorBrewer)
  col1 <- brewer.pal(6, "Set1")     # the maximum of brewer.pal is 12
  #col2 <- brewer.pal(5, "Pastel1")
  #tol21rainbow= c("#771155", "#AA4488", "#CC99BB", "#114477", "#4477AA", "#77AADD", "#117777", "#44AAAA", "#77CCCC", "#117744", "#44AA77", "#88CCAA", "#777711", "#AAAA44", "#DDDD77", "#774411", "#AA7744", "#DDAA77", "#771122", "#AA4455", "#DD7788")
  if(length(unique(colnames(mydata)))>25){
    tol21rainbow<-rainbow(length(unique(colnames(mydata))))
  }else{
    tol21rainbow <- c("dodgerblue2","#E31A1C", # red
                      "green4",
                      "#6A3D9A", # purple
                      "#FF7F00", # orange
                      "black","gold1",
                      "skyblue2","#FB9A99", # lt pink
                      "palegreen2",
                      "#CAB2D6", # lt purple
                      "#FDBF6F", # lt orange
                      "gray70", "khaki2",
                      "maroon","orchid1","deeppink1","blue1","steelblue4",
                      "darkturquoise","green1","yellow4","yellow3",
                      "darkorange4","brown")
  }
  col2<-tol21rainbow[as.numeric(as.factor(cl.col$labels))]
  col=colorRampPalette(c("blue", "yellow"))(20) 
  pdf(output)
  par(mar=c(5,5,5,0))
  heatmaprlt<-heatmap.2(as.matrix(mydata),hclustfun=hclustfunc, distfun=distfunc,
                        RowSideColors=col1[gr.row], 
                        ColSideColors=col2,
                        cexRow=cexRow,cexCol=cexCol,
                        labRow=F,
                        trace="none",
                        col=col,
                        na.color="black",
                        density.info="none")
  legend=unique(data.frame(col2,cl.col$labels))
  legend(x=0.85,y=0.8,legend=legend[,2],col=as.character(legend[,1]),pch=15,cex = 0.5,bty="n")
  dev.off()
  return(heatmaprlt)
}
