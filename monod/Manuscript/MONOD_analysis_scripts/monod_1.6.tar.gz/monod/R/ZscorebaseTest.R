#' calculate Z-score and optimize the best MHL threshold for cancer plasma and normal plasma(test dataset)
#' @param tissue-specific biomarker counts in cancer plasma and normal plasma 
#' @return Z-score matrix
#' @export
ZscorebaseTest<-function(data,bio){
  Sum<-c()
  for(tt in seq(0,0.6,by=0.01)){
    input<-data[match(rownames(bio),rownames(data)),]
    set.seed(1)
    np<-input[,grep("NC.P",colnames(input))]  
    ccp<-input[,grep(".6P|X6.P",colnames(input))]  
    lcp<-input[,grep(".7P|X7.P",colnames(input))] 
    train<-sample(1:75,45)
    trainset<-np[,train]
    testset<-np[,(1:75)[-train]]
    npr<-apply(trainset,2,function(x) table(unlist(lapply(bio[match(rownames(trainset)[which(x>tt)],rownames(bio)),]$group,function(x) unlist(strsplit(x,","))))))
    ccpr<-apply(ccp,2,function(x) table(unlist(lapply(bio[match(rownames(ccp)[which(x>tt)],rownames(bio)),]$group,function(x) unlist(strsplit(x,","))))))
    lcpr<-apply(lcp,2,function(x) table(unlist(lapply(bio[match(rownames(ccp)[which(x>tt)],rownames(bio)),]$group,function(x) unlist(strsplit(x,","))))))
    nnpr<-apply(trainset,2,function(x) table(unlist(lapply(bio[match(rownames(trainset)[which(x>tt)],rownames(bio)),]$group,function(x) unlist(strsplit(x,","))))))
    rlt1<-sum(apply(Zscore(ccpr,npr),2,function(x) which.max(x)==2))/ncol(ccp)
    rlt2<-sum(apply(Zscore(lcpr,npr),2,function(x) which.max(x)==6))/ncol(lcp)
    rlt3<-sum(apply(Zscore(nnpr,npr),2,function(x) which.max(x)==10))/ncol(testset)
    Sum<-rbind(Sum,c(ccp=rlt1,lcp=rlt2,npc=rlt3,total=rlt1+rlt2+rlt3))
  }
  return(Sum)
}
